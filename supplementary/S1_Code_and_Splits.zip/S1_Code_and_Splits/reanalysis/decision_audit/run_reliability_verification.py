"""Extended verification of the panel-reliability signal.

Executes exactly what PREREG_RELIABILITY.json locks: 400 split-half estimates,
bootstrap CIs, partial correlations, ICC(2,1)/ICC(3,1) robustness, leave-one-out,
and low-rho/high-reliability counterexample census.

Honesty: this is an EXTENDED VERIFICATION of an exploratory observation, not a
pure preregistered confirmatory test. See the prereg provenance_honesty field.
"""
from pathlib import Path
import json
import numpy as np, pandas as pd
from scipy.stats import spearmanr

HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"

def locate(fn, local_name, absolute_fallback):
    """Prefer the copy shipped inside this archive; fall back to the author's tree."""
    c = INPUTS / local_name
    if c.exists():
        return c
    if Path(absolute_fallback).exists():
        return Path(absolute_fallback)
    raise FileNotFoundError(
        f"{fn}: ship {local_name} in decision_audit/inputs/ or provide {absolute_fallback}")

ROOT = Path("E:/啤酒")
NESTED = ROOT / "MathorCup_2026A_Reproducible_Package/MathorCup_2026A_Reproducible/analysis_2026a/q1_runs/nested_v1/oof"

raw = pd.read_csv(locate("raw sensory scores", "Raw_sensory_data_anonymized.csv",
                         ROOT / "Raw sensory data anonymized (1).csv"), encoding="cp1252")
truth = pd.read_csv(locate("continuous panel truth", "truth_continuous.csv",
                           NESTED / "truth_continuous.csv"))
adaptive = pd.read_csv(locate("out-of-fold predictions", "adaptive.csv",
                              NESTED / "adaptive.csv"))
targets = [c for c in truth.columns if c not in ("beer", "outer_fold")]
ren = {"A_esters_fruity": "A_ester_fruity", "F_esters_fruity": "F_ester_fruity"}
tasters = sorted(raw.taster.unique())

# observed rho (the manuscript numbers)
rho = np.array([spearmanr(truth[t], adaptive[t]).statistic for t in targets])

N_SPLITS = 400
SEEDS = [2601731 + k for k in range(N_SPLITS)]


def sb_full(r_half):
    return 2 * r_half / (1 + r_half)


def matrix_for(rc):
    m = raw.pivot_table(index="beer_name", columns="taster", values=rc, aggfunc="mean")
    return m.reindex(columns=tasters).to_numpy(float)


def floor_fraction(col):
    v = col[~np.isnan(col)]
    return float(np.mean(v <= np.nanmin(v) + 1e-9))


# ---------------- primary: split-half Spearman, 400 splits ----------------
rows = []
for t, rc in zip(targets, [ren.get(x, x) for x in targets]):
    A = matrix_for(rc)
    rs = []
    n_skip = 0
    for s in SEEDS:
        perm = np.random.default_rng(s).permutation(len(tasters))
        a, b = perm[:8], perm[8:]
        ma = np.nanmean(A[:, a], axis=1)
        mb = np.nanmean(A[:, b], axis=1)
        ok = ~np.isnan(ma) & ~np.isnan(mb)
        if ok.sum() < 100 or np.std(ma[ok]) < 1e-9 or np.std(mb[ok]) < 1e-9:
            n_skip += 1
            continue
        rs.append(spearmanr(ma[ok], mb[ok]).statistic)
    r_half = float(np.mean(rs))
    full = np.nanmean(A, axis=1)
    rows.append(dict(target=t, rho=float(rho[targets.index(t)]),
                     r_half=r_half, panel_rel=sb_full(r_half),
                     n_valid=len(rs), n_skip=n_skip,
                     floor=floor_fraction(full), sd=float(np.nanstd(full)),
                     rho_corr=float(rho[targets.index(t)] / np.sqrt(sb_full(r_half)))))
d = pd.DataFrame(rows)


# ---------------- bootstrap CI helper (over attributes) ----------------
def boot_ci_spearman(x, y, n_boot=2000, seed=2601731):
    rng = np.random.default_rng(seed)
    out = []
    n = len(x)
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        if np.std(x[idx]) == 0 or np.std(y[idx]) == 0:
            continue
        out.append(spearmanr(x[idx], y[idx]).statistic)
    return float(np.quantile(out, 0.05)), float(np.quantile(out, 0.95))


def partial_spearman(x, y, z):
    rx = spearmanr(x, z).statistic
    ry = spearmanr(y, z).statistic
    rxy = spearmanr(x, y).statistic
    return float((rxy - rx * ry) / np.sqrt((1 - rx ** 2) * (1 - ry ** 2)))


primary = spearmanr(d.rho, d.panel_rel).statistic
lo, hi = boot_ci_spearman(d.rho.to_numpy(), d.panel_rel.to_numpy())
part_sd = partial_spearman(d.rho.to_numpy(), d.panel_rel.to_numpy(), d.sd.to_numpy())
part_floor = partial_spearman(d.rho.to_numpy(), d.panel_rel.to_numpy(), d.floor.to_numpy())

result = dict(
    n_attributes=len(d),
    mean_panel_reliability=float(d.panel_rel.mean()),
    primary_spearman=float(primary),
    primary_ci90=[lo, hi],
    partial_controlling_sd=part_sd,
    partial_controlling_floor=part_floor,
    mean_splits_per_attribute=float(d.n_valid.mean()),
    total_skipped_splits=int(d.n_skip.sum()),
)

# ---------------- quartile summary ----------------
q = np.quantile(d.rho, [0.25, 0.5, 0.75])
quart = []
for name, mask in [("Q1_weakest", d.rho <= q[0]),
                   ("Q2", (d.rho > q[0]) & (d.rho <= q[1])),
                   ("Q3", (d.rho > q[1]) & (d.rho <= q[2])),
                   ("Q4_strongest", d.rho > q[2])]:
    s = d[mask]
    quart.append(dict(group=name, n=len(s), rho=float(s.rho.mean()),
                      panel_rel=float(s.panel_rel.mean()),
                      floor=float(s.floor.mean()),
                      rho_corr=float(s.rho_corr.mean())))
result["quartiles"] = quart

# ---------------- robustness: pairwise inter-assessor rank agreement ----------------
# NOTE: no beer has all 16 assessors, so complete-case ANOVA ICC is undefined.
# Instead use the mean pairwise Spearman between assessors, Spearman-Brown to 16.
from itertools import combinations

def pairwise_reliability(A):
    rs = []
    for i, j in combinations(range(A.shape[1]), 2):
        a, b = A[:, i], A[:, j]
        ok = ~np.isnan(a) & ~np.isnan(b)
        if ok.sum() < 50 or np.std(a[ok]) < 1e-9 or np.std(b[ok]) < 1e-9:
            continue
        rs.append(spearmanr(a[ok], b[ok]).statistic)
    single = float(np.mean(rs))
    return 16 * single / (1 + 15 * single), single, len(rs)

icc_rows = []
for t, rc in zip(targets, [ren.get(x, x) for x in targets]):
    A = matrix_for(rc)
    rel16, single, npair = pairwise_reliability(A)
    icc_rows.append(dict(target=t, rho=float(rho[targets.index(t)]),
                         pairwise_single=single, pairwise_rel16=rel16, n_pairs=npair))
ic = pd.DataFrame(icc_rows)
result["icc_robustness"] = {
    "method": "mean pairwise inter-assessor Spearman, Spearman-Brown to 16; complete-case ICC undefined (0 beers fully rated)",
    "spearman_rho_vs_pairwise_rel16": float(spearmanr(ic.rho, ic.pairwise_rel16).statistic),
    "mean_pairwise_rel16": float(ic.pairwise_rel16.mean()),
    "mean_single_rater_r": float(ic.pairwise_single.mean()),
}

# ---------------- robustness: 100 vs 400 splits ----------------
r100 = []
for t, rc in zip(targets, [ren.get(x, x) for x in targets]):
    A = matrix_for(rc)
    rs = []
    for s in SEEDS[:100]:
        perm = np.random.default_rng(s).permutation(len(tasters))
        a, b = perm[:8], perm[8:]
        ma = np.nanmean(A[:, a], axis=1); mb = np.nanmean(A[:, b], axis=1)
        ok = ~np.isnan(ma) & ~np.isnan(mb)
        if ok.sum() < 100 or np.std(ma[ok]) < 1e-9 or np.std(mb[ok]) < 1e-9:
            continue
        rs.append(spearmanr(ma[ok], mb[ok]).statistic)
    r100.append(sb_full(float(np.mean(rs))))
result["splits_robustness"] = {
    "rho_vs_rel_100_splits": float(spearmanr(rho, r100).statistic),
    "rho_vs_rel_400_splits": primary,
}

# ---------------- leave-one-attribute-out ----------------
loo = []
for i in range(len(d)):
    m = np.arange(len(d)) != i
    loo.append(spearmanr(d.rho.to_numpy()[m], d.panel_rel.to_numpy()[m]).statistic)
result["loo"] = dict(min=float(min(loo)), max=float(max(loo)),
                     n_below_0_3=int(sum(v < 0.3 for v in loo)))

# ---------------- counterexample census (F4) ----------------
ce = d[(d.rho < np.median(d.rho)) & (d.panel_rel >= 0.5)]
result["counterexamples_low_rho_high_rel"] = dict(
    n=len(ce), fraction=float(len(ce) / len(d)),
    targets=ce.target.tolist())

# ---------------- falsification ----------------
F = {
    "F1_primary_ci_lower_gt_0_3": bool(lo > 0.3),
    "F2_partial_sd_gt_0_2": bool(part_sd > 0.20),
    "F3_pairwise_consistent": bool(result["icc_robustness"]["spearman_rho_vs_pairwise_rel16"] >= 0.3),
    "F4_counterexamples_lt_25pct": bool(len(ce) / len(d) < 0.25),
}
result["falsification"] = F
result["verdict"] = "SUPPORTED" if all(F.values()) else "NOT SUPPORTED - see falsification flags"

# ---------------- save ----------------
d.to_csv(HERE / "reliability_verification_by_attr.csv", index=False)
ic.to_csv(HERE / "icc_robustness_by_attr.csv", index=False)
(HERE / "VERIFICATION_RESULT.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

print(json.dumps(result, indent=2))
