"""Post-hoc sensitivity (NOT preregistered): use a FAIR panel benchmark.

The preregistered benchmark compared a half-panel against the full panel that
CONTAINS that half, inflating agreement (BA~0.88 for alcohol). This sensitivity
uses two DISJOINT halves of the panel, which is the honest independent
reproducibility ceiling. Chemistry is compared against that ceiling.

Run for the three prespecified strong-correspondence targets.
"""
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent
ROOT = Path("E:/啤酒")
NESTED = ROOT / "MathorCup_2026A_Reproducible_Package/MathorCup_2026A_Reproducible/analysis_2026a/q1_runs/nested_v1/oof"
RAW = ROOT / "Raw sensory data anonymized (1).csv"
df = pd.read_csv(RAW, encoding="cp1252")
truth = pd.read_csv(NESTED / "truth_continuous.csv")
adaptive = pd.read_csv(NESTED / "adaptive.csv")
mapdf = pd.read_csv(HERE.parent / "raw_panel_beer_map.csv", encoding="utf-8-sig")
raw2off = dict(zip(mapdf.beer_name_raw, mapdf.official_beer_4csv))

def flags(a, q=0.8):
    a = np.asarray(a, dtype=float)
    return a >= np.quantile(a, q)

def ba(p, r):
    pp = r.sum(); nn = (~r).sum()
    return 0.5 * ((p & r).sum() / pp + ((~p) & (~r)).sum() / nn)

rows = []
for col in ["alcohol", "bitternes", "body", "A_esters_flower", "F_esters_flower", "dms"]:
    raw_col = {"A_esters_flower": "A_ester_fruity", "F_esters_flower": "F_ester_fruity"}.get(col, col)
    cell = df.groupby(["beer_name", "taster"])[raw_col].mean()
    tasters = sorted(df.taster.unique())
    j = list(truth.columns).index(col)
    # chemistry BA: prediction flags vs full-panel truth flags (own quantiles)
    y = truth[col].to_numpy(float)
    p = adaptive[col].to_numpy(float)
    chem_ba = ba(flags(p), flags(y))
    # independent 8-vs-8 BA on the raw 0-6 scores
    vals = []
    for k in range(200):
        perm = np.random.default_rng(2601731 + k).permutation(tasters)
        parts_a = [cell.xs(t, level="taster").dropna() for t in perm[:8]]
        parts_b = [cell.xs(t, level="taster").dropna() for t in perm[8:]]
        ma = pd.concat(parts_a).groupby(level=0).mean()
        mb = pd.concat(parts_b).groupby(level=0).mean()
        common = ma.index.intersection(mb.index)
        vals.append(ba(flags(ma.loc[common].values), flags(mb.loc[common].values)))
    fair_ba = float(np.mean(vals))
    # bootstrap CI for the gap: resample beers for chemistry, resample split draws for panel
    rng = np.random.default_rng(2601731)
    yf = flags(y); pf = flags(p)
    gaps = []
    for _ in range(2000):
        idx = rng.integers(0, len(y), len(y))
        cboot = ba(pf[idx], yf[idx])
        pboot = np.mean(rng.choice(vals, 200, replace=True))
        gaps.append(cboot - pboot)
    lo, hi = np.quantile(gaps, [0.05, 0.95])
    rows.append(dict(target=col, chemistry_BA=chem_ba, panel_independent_BA=fair_ba,
                     gap=chem_ba - fair_ba, gap_ci90_lo=float(lo), gap_ci90_hi=float(hi),
                     noninferior_delta005=bool(lo > -0.05),
                     stratum="strong" if col in ["alcohol","bitternes","body"] else "weak"))
out = pd.DataFrame(rows)
out.to_csv(HERE / "fair_benchmark_sensitivity.csv", index=False)
print(out.to_string(index=False))
