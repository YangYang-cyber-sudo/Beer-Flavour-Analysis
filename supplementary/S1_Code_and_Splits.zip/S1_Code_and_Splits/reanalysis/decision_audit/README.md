# Panel-reliability analysis (manuscript Sections 2.6, 3.10, Table 9)

This directory contains the code and results for the panel-reliability analysis
reported in the manuscript: the observation that the chemistry–sensory rank
correspondence (ρ) is bounded above by how reproducibly the trained panel can
score each attribute.

## Provenance and honesty statement

The analysis began as an **exploratory** observation (`PANEL_RELIABILITY_FINDING.md`,
based on 60 split draws). Its design — including four prespecified falsification
conditions — was then locked in `PREREG_RELIABILITY.json` **before** the extended
rerun. It is therefore an **extended verification of an exploratory signal**, not
a purely confirmatory pre-registered test. This distinction is stated in the
manuscript (Sections 2.6 and 3.10).

## Files

| File | Role |
|---|---|
| `run_reliability_verification.py` | Executable that reproduces every number in Section 3.10 and Table 9 |
| `PREREG_RELIABILITY.json` | Locked design and the four falsification conditions |
| `VERIFICATION_RESULT.json` | Headline results, quartiles, robustness checks, verdict |
| `VERIFICATION_CONCLUSION.md` | Human-readable conclusion and mandatory caveats |
| `reliability_verification_by_attr.csv` | Per-attribute ρ, split-half r, full-panel reliability, floor, SD, corrected ρ |
| `pairwise_reliability_by_attr.csv` | Independent reliability estimator (mean pairwise assessor Spearman) |
| `icc_robustness_by_attr.csv` | Per-attribute pairwise reliability and agreement details |
| `panel_reliability_by_attr.csv`, `attenuation_by_attr.csv` | Earlier 60-split exploratory estimates (superseded by the 400-split rerun) |
| `PANEL_RELIABILITY_FINDING.md` | Original exploratory finding and its caveats |
| `inputs/` | The three input tables required to rerun the script (see below) |
| `PREREGISTRATION.json`, `run_a1_a2.py`, `a1_*`, `a2_*`, `REPORT.md`, `fair_benchmark_sensitivity.*` | Earlier decision-audit work (A1/A2), **not** reported in this manuscript; retained for completeness |

## Reproducing the analysis

```
python reanalysis/decision_audit/run_reliability_verification.py
```

The script resolves its three inputs in this order:

1. `reanalysis/decision_audit/inputs/` inside this archive (shipped here);
2. the author's original local paths (fallback only).

| Input shipped in `inputs/` | Source |
|---|---|
| `Raw_sensory_data_anonymized.csv` | Schreurs et al. (2024), anonymised assessor-level sensory scores (public Zenodo deposit) |
| `truth_continuous.csv` | Continuous panel-score targets used in the manuscript |
| `adaptive.csv` | Out-of-fold predictions from the frozen nested cross-validation |

Requires `numpy`, `pandas`, `scipy`. The script rewrites
`VERIFICATION_RESULT.json`, `reliability_verification_by_attr.csv` and
`icc_robustness_by_attr.csv` in place; its console output is the full result JSON.

## Method summary (for cross-checking against the manuscript)

- For each of 50 attributes, 400 random disjoint 8-vs-8 splits of the 16 assessors;
  Spearman correlation of the two half-panel beer means; scaled to the full panel
  with Spearman–Brown, `r_full = 2·r_half/(1 + r_half)`.
- ρ = Spearman correlation between the manuscript's nested-CV out-of-fold
  prediction and the continuous panel score.
- Partial Spearman correlations controlling score SD and near-floor fraction.
- Independent estimator: mean pairwise inter-assessor Spearman, scaled to 16
  assessors as `16r/(1 + 15r)` (complete-case ICC is undefined: no beer was rated
  by all 16 assessors).
- Classical attenuation: `ρ_corrected = ρ / sqrt(r_full)` — sensitivity estimates
  only; assumes error-free chemistry and independent errors.
- Four prespecified falsification conditions (F1 primary 90% CI lower bound > 0.30;
  F2 partial ρ controlling SD > 0.20; F3 independent estimator ≥ 0.30; F4
  low-ρ/high-reliability counterexamples < 25%); all four passed.

## Mandatory caveats (also in the manuscript)

1. An upper bound, not a deterministic per-attribute rule: three attributes
   (metallic, acetic, overall) had low ρ despite high reliability.
2. High reliability is not discriminability: acetic had reliability 0.853 while
   80% of beers sat at floor.
3. Attenuation-corrected ρ values are sensitivity estimates, not corrected facts.
4. Exploratory origin must be disclosed.
5. The analysis does **not** rehabilitate reassigning monitoring responsibilities;
   it changes the reference standard against which correspondence is judged.
