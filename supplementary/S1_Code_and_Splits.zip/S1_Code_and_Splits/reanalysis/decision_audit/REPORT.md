# A1 + A2 decision-level audit — result direction

Run 2026-11-24. All outputs in this directory. Pre-registration locked in
`PREREGISTRATION.json` before any result was inspected.

## What was tested

The editor said associations and prediction errors do not demonstrate that
chemistry can replace the panel with acceptable accuracy under QC conditions.
A1/A2 convert the problem into a **decision**: is a beer flagged as "notably
present" for an attribute (>80th percentile of that source's own distribution)?
Chemistry out-of-fold predictions (the exact nested-CV `adaptive.csv` used in
the manuscript) and panel scores are scored as binary decisions against the
full-panel decision, using balanced accuracy (BA).

## A1 — headline preregistered result (UNFAVOURABLE)

- Chemistry BA = **0.661** (95% CI 0.644–0.677)
- Preregistered panel benchmark (8-assessor half vs the 16-assessor panel that
  CONTAINS it) BA = **0.796** (95% CI 0.786–0.799)
- Gap = **−0.136** (90% CI −0.148 to −0.123), far beyond δ=0.05.
- Non-inferiority at δ=0.05: **NOT established** for any of the six
  prespecified targets (3 strong, 3 weak); only 4/44 "other" targets passed.

**Why this benchmark is flawed:** the half-panel is a subset of the reference
panel, so it scores against a decision that embeds its own ratings. This
inflates the panel ceiling. Diagnostic on `alcohol`: half-vs-full BA 0.88 vs
two DISJOINT halves 0.77 (8v8) / 0.69 (4v4).

## A1/A2 sensitivity with a FAIR benchmark (POST-HOC, clearly labelled)

Using two disjoint 8-assessor halves as the panel's independent reproducibility
ceiling, and chemistry vs full panel:

| target | chem BA | panel independent BA | gap | 90% CI of gap | NI δ=0.05 |
|---|---|---|---|---|---|
| alcohol (strong) | 0.738 | 0.760 | −0.023 | −0.083 to 0.036 | not established |
| bitternes (strong) | 0.763 | 0.741 | +0.022 | −0.037 to 0.082 | **established** |
| body (strong) | 0.675 | 0.675 | −0.000 | −0.062 to 0.064 | not established |
| A_esters_flower (weak) | 0.575 | 0.597 | −0.022 | −0.078 to 0.035 | not established |
| F_esters_flower (weak) | 0.575 | 0.594 | −0.019 | −0.076 to 0.041 | not established |
| dms (weak) | 0.613 | 0.603 | +0.010 | −0.048 to 0.073 | **established** |

Reading: with a fair benchmark, chemistry's decision accuracy is within about
±0.02 BA of the panel's own independent reproducibility on all six named
attributes — statistically the gaps are small, but the CIs are wide (~±0.06)
because 200 half-splits overlap in assessors, so formal non-inferiority is only
met for 2 of 6. Direction is **promising, not conclusive**.

## Honest conclusion on direction

1. The preregistered analysis, as specified, does **not** support replacement.
   Reported verbatim it would confirm the editor.
2. The failure is largely an artefact of an unfair benchmark; with a fair
   (disjoint-panel) benchmark the chemistry decision accuracy is close to the
   panel's own reproducibility, which is the defensible way to frame
   "acceptable accuracy". But CIs are too wide to claim non-inferiority for
   most attributes with the current design.
3. This is enough to justify continuing to A3/A4 **only if** the analysis is
   reframed around the fair benchmark AND the claim is narrowed to "decision
   accuracy comparable to panel reproducibility on a specified subset", not
   blanket replacement. It does NOT by itself rescue the original strong
   allocation claim.

## Files

- `PREREGISTRATION.json` — locked definitions, margins, falsification rule
- `run_a1_a2.py` — preregistered analysis (uses half-vs-full benchmark)
- `a1_decision_metrics.csv`, `a1_summary.json` — A1 outputs
- `a2_tost_by_target.csv`, `a2_summary.json` — A2 outputs
- `fair_benchmark_sensitivity.py`, `fair_benchmark_sensitivity.csv` — post-hoc
  fair-benchmark sensitivity (clearly not preregistered)

## Caveats for any manuscript use

- All numbers are at the 0.80 quantile line; 0.70/0.90 sensitivity lines are in
  the script but the pattern should be checked before quoting.
- 200 half-splits are not independent; CIs on the fair benchmark are
  optimistic-to-moderate and the per-target NI decisions are unstable.
- Scale-free by construction (each source uses its own quantile), so no claim
  about absolute grade reproduction is made here.
