# Extended verification — conclusion (2026-11-24)

Provenance: EXTENDED VERIFICATION of an exploratory signal, not a pure
preregistered confirmatory test. Design locked in `PREREG_RELIABILITY.json`
before the extended rerun. Full results in `VERIFICATION_RESULT.json`.

## Verdict: SUPPORTED (all four prespecified falsification conditions passed)

| check | result | threshold | pass |
|---|---|---|---|
| F1 primary Spearman(rho, panel reliability), 90% CI | 0.770 [0.655, 0.850] | CI lower > 0.30 | yes |
| F2 partial controlling score SD | 0.637 | > 0.20 | yes |
| F3 independent estimator (pairwise assessor rank agreement) | 0.604 | >= 0.30 | yes |
| F4 low-rho/high-reliability counterexamples | 3/50 = 6% | < 25% | yes |

Additional stability:
- 100 splits 0.767 vs 400 splits 0.770 — point estimate insensitive to split count.
- Leave-one-attribute-out range 0.759–0.799; never drops below 0.3.
- Partial correlation controlling BOTH SD and floor = 0.702.
- Split-half vs pairwise reliability estimates correlate 0.887 with each other.

## The usable scientific claim (carefully worded)
Attribute-level correspondence between chemistry and sensory scores is bounded
above by how reproducibly the panel can score that attribute. Across 50
attributes, rho tracks panel reliability (0.770); attributes with weak
correspondence concentrate where the panel's own 16-assessor reproducibility is
lowest (Q1 rho 0.20 / reliability 0.30 / 29% of beers pinned at floor), whereas
strong-correspondence attributes have high panel reliability (~0.70). Classical
attenuation implies observed rho in the weak group substantially understates
the chemistry-perception association (Q1 0.20 -> 0.41 corrected; Q4 0.67 -> 0.80).

## Mandatory caveats for the manuscript
1. **High reliability is not the same as discriminability.** acetic has
   reliability 0.853 but 80% of beers at floor: the panel is consistently
   uninformative. The claim is an upper bound, not "reliable panel = monitorable".
2. **Counterexamples exist** (metallic, acetic, overall: low rho, high
   reliability). Therefore the claim is about a ceiling/population tendency,
   NOT a deterministic rule per attribute.
3. **Floor-stratified**: low-floor attributes corr 0.867, high-floor 0.574 —
   the relationship holds in both strata but is weaker where floor dominates.
4. Exploratory origin must be disclosed; attenuation assumes error-free
   chemistry and independent errors; corrected rho values are sensitivity
   estimates.
5. This does NOT rehabilitate "monitoring responsibilities can be reassigned".
   It changes the reference standard against which correspondence is judged.

## Files
- `PREREG_RELIABILITY.json`, `VERIFICATION_RESULT.json`
- `reliability_verification_by_attr.csv` (primary, 400 splits)
- `pairwise_reliability_by_attr.csv` (independent estimator)
- `run_reliability_verification.py` (executable, reproduces all)
