"""A1 decision-level agreement + A2 non-inferiority, executed per PREREGISTRATION.json.

Everything here is scale-free: each information source is flagged by its own
within-target quantile, and all sources are scored against the full-panel flags.
No result is used to select targets, lines, margins or metrics.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats

HERE = Path(__file__).resolve().parent
RA = HERE.parent
ROOT = RA.parent.parent.parent  # E:/啤酒
NESTED = ROOT / "MathorCup_2026A_Reproducible_Package/MathorCup_2026A_Reproducible/analysis_2026a/q1_runs/nested_v1/oof"
RAW = ROOT / "Raw sensory data anonymized (1).csv"
SEED = 2601731
rng_global = np.random.default_rng(SEED)

reg = json.loads((HERE / "PREREGISTRATION.json").read_text(encoding="utf-8"))
LINES = [0.80, 0.70, 0.90]
N_BOOT = 2000
N_SPLIT = 200

# ---------------------------------------------------------------- load sources
adaptive = pd.read_csv(NESTED / "adaptive.csv")
truth = pd.read_csv(NESTED / "truth_continuous.csv")
assert (adaptive.beer.values == truth.beer.values).all()
targets = [c for c in truth.columns if c not in ("beer", "outer_fold")]
y_pred = adaptive[targets].to_numpy(float)      # 250 x 50
y_full = truth[targets].to_numpy(float)         # 250 x 50

# raw tasting records -> per (beer, taster) mean on 0-6 scale
df = pd.read_csv(RAW, encoding="cp1252")
desc = [c for c in df.columns if c.startswith(("A_", "F_")) or c in [
    "body", "bitternes", "co2", "aftertaste", "alcohol", "sweetness", "acidity",
    "dms", "metallic", "X4vg", "t2n", "diacetyl", "stale_hops", "orange",
    "coriander", "clove", "lactic", "acetic", "barnyard", "overall"]]
# raw table uses singular 'ester' for the two fruity columns; truth uses plural
name_map = {"A_esters_fruity": "A_ester_fruity", "F_esters_fruity": "F_ester_fruity"}
assert set(targets) <= set(desc) or set(targets) <= set(desc) | set(name_map)
raw_for_target = {t: name_map.get(t, t) for t in targets}
assert set(raw_for_target.values()) <= set(desc)
cell = df.groupby(["beer_name", "taster"])[list(raw_for_target.values())].mean()
cell.columns = targets
tasters = sorted(df.taster.unique())
beer_map = pd.read_csv(RA / "raw_panel_beer_map.csv", encoding="utf-8-sig")
raw2off = dict(zip(beer_map.beer_name_raw, beer_map.official_beer_4csv))
# official id order must match truth beer order
off_beers = truth.beer.to_numpy()
assert set(raw2off.values()) == set(off_beers)

# build half-panel matrices aligned to truth beer order, on 0-6 scale.
# Coverage is highly unequal across tasters (22..224 beers), so a naive random
# 8-person half leaves some beers with no rating. We restrict sampling to the
# 8-person combinations that cover ALL 250 beers, and draw 200 of those with a
# fixed seed. No imputation and no beer is dropped. This is a technical
# tightening of the preregistered half-panel rule (see run log).
import itertools
coverage = (cell.notna().any(axis=2)).astype(int) if cell.ndim == 3 else None
# rebuild presence from the raw table directly
pres = (df.groupby(["beer_name", "taster"])[raw_for_target["alcohol"]].count() > 0).unstack(fill_value=0)
valid_halves = [c for c in itertools.combinations(tasters, len(tasters)//2)
                if (pres.loc[:, c].sum(axis=1) > 0).all()]
assert len(valid_halves) > N_SPLIT, len(valid_halves)
chosen = [valid_halves[i] for i in rng_global.choice(len(valid_halves), N_SPLIT, replace=False)]
half_mats = []
for half in chosen:
    sub = cell.loc[(slice(None), list(half)), :].groupby("beer_name").mean()
    sub.index = [raw2off[b] for b in sub.index]
    sub = sub.reindex(off_beers)
    assert sub.notna().all().all()
    half_mats.append(sub[targets].to_numpy(float))
half_mats = np.stack(half_mats)   # 200 x 250 x 50

# ---------------------------------------------------------------- helpers
def flags(source, q):
    """Flag by each source's own within-target q-quantile."""
    return source >= np.quantile(source, q, axis=0)

def confusion(pred, ref):
    tp = np.logical_and(pred, ref).sum()
    fp = np.logical_and(pred, ~ref).sum()
    fn = np.logical_and(~pred, ref).sum()
    tn = np.logical_and(~pred, ~ref).sum()
    sens = tp / (tp + fn) if tp + fn else np.nan
    spec = tn / (tn + fp) if tn + fp else np.nan
    ppv = tp / (tp + fp) if tp + fp else np.nan
    npv = tn / (tn + fn) if tn + fn else np.nan
    ba = 0.5 * (sens + spec)
    return dict(sensitivity=sens, specificity=spec, balanced_accuracy=ba,
                ppv=ppv, npv=npv, tp=int(tp), fp=int(fp), fn=int(fn), tn=int(tn))

# ---------------------------------------------------------------- A1
rows = []
for q in LINES:
    ref = flags(y_full, q)
    for name, src in [("chemistry", y_pred), ("panel_full_self", y_full),
                      ("panel_half", None)]:
        if name == "panel_full_self":
            # sanity: flagging the reference by its own line is trivially perfect
            continue
        if name == "panel_half":
            for s in range(N_SPLIT):
                m = confusion(flags(half_mats[s], q), ref)
                rows.append(dict(line=q, source=name, split=s, target="POOLED", **m))
        else:
            rows.append(dict(line=q, source=name, split=-1, target="POOLED",
                             **confusion(flags(src, q), ref)))
    # per target for chemistry and mean over half splits
    for j, t in enumerate(targets):
        rows.append(dict(line=q, source="chemistry", split=-1, target=t,
                         **confusion(flags(y_pred[:, j:j+1], q)[:, 0], ref[:, j])))
pooled = pd.DataFrame(rows)
pooled.to_csv(HERE / "a1_decision_metrics.csv", index=False)

# ---------------------------------------------------------------- A1 bootstrap CIs (pooled, primary line only)
q = LINES[0]
ref = flags(y_full, q)
chem_f = flags(y_pred, q)
half_ba = np.array([confusion(flags(half_mats[s], q), ref)["balanced_accuracy"]
                    for s in range(N_SPLIT)])
boot_rng = np.random.default_rng(SEED)
boot = {"chemistry": [], "panel_half": []}
for _ in range(N_BOOT):
    idx = boot_rng.integers(0, len(off_beers), len(off_beers))
    boot["chemistry"].append(confusion(chem_f[idx], ref[idx])["balanced_accuracy"])
    boot["panel_half"].append(np.mean([
        confusion(flags(half_mats[s], q)[idx], ref[idx])["balanced_accuracy"]
        for s in range(min(20, N_SPLIT))]))

def ci(arr):
    return [float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))]

a1_summary = {
    "primary_line": q,
    "n_beers": int(len(off_beers)),
    "n_half_splits": N_SPLIT,
    "chemistry_BA": confusion(chem_f, ref)["balanced_accuracy"],
    "chemistry_BA_CI95": ci(boot["chemistry"]),
    "panel_half_BA_mean": float(half_ba.mean()),
    "panel_half_BA_sd": float(half_ba.std()),
    "panel_half_BA_CI95": ci(boot["panel_half"]),
}
(HERE / "a1_summary.json").write_text(json.dumps(a1_summary, indent=2), encoding="utf-8")

# ---------------------------------------------------------------- A2 TOST
# Precompute the 200 half-panel flag matrices ONCE (each source flagged by its
# own within-target quantile, per preregistration).
half_flags = [flags(hm, q) for hm in half_mats]

def per_target_ba(pred_f, ref_f, idx):
    """Balanced accuracy per target on a beer subsample."""
    p, r = pred_f[idx], ref_f[idx]
    pp = r.sum(axis=0); nn = (~r).sum(axis=0)
    return 0.5 * (((p & r).sum(axis=0) / pp) + (((~p) & (~r)).sum(axis=0) / nn))

# Point estimates.
chem_ba_t = per_target_ba(chem_f, ref, np.arange(len(off_beers)))
half_ba_t = np.mean([per_target_ba(hf, ref, np.arange(len(off_beers)))
                     for hf in half_flags], axis=0)
diff_t = chem_ba_t - half_ba_t
assert abs(chem_ba_t.mean() - confusion(chem_f, ref)["balanced_accuracy"]) < 1e-9
assert abs(half_ba_t.mean() - a1_summary["panel_half_BA_mean"]) < 1e-9

# One paired beer-level bootstrap -> both the macro CI and the per-target CIs.
brng = np.random.default_rng(SEED + 7)
macro_boot = []
per_target_boot = []
for _ in range(N_BOOT):
    idx = brng.integers(0, len(off_beers), len(off_beers))
    cb = per_target_ba(chem_f, ref, idx)
    hb = np.mean([per_target_ba(hf, ref, idx)
                  for hf in half_flags[::10]], axis=0)   # 20 half-splits
    dvec = cb - hb
    per_target_boot.append(dvec)
    macro_boot.append(dvec.mean())
per_target_boot = np.array(per_target_boot)
macro_boot = np.array(macro_boot)

m_macro = float(diff_t.mean())
lo_macro, hi_macro = [float(v) for v in np.quantile(macro_boot, [0.05, 0.95])]
delta = reg["A2_noninferiority"]["margin_delta"]
delta_s = reg["A2_noninferiority"]["sensitivity_margin"]

def ni(m, lo, hi, d):
    return dict(mean_diff=m, ci90=[lo, hi], delta=d, noninferior=bool(lo > -d))

a2 = {
    "primary_delta": delta,
    "primary_tost": ni(m_macro, lo_macro, hi_macro, delta),
    "sensitivity_delta": delta_s,
    "sensitivity_tost": ni(m_macro, lo_macro, hi_macro, delta_s),
    "method": "paired beer-level bootstrap of (BA_model - BA_panelhalf), 2000 resamples, 90% percentile CI; panelhalf averaged over 20 of the 200 coverage-complete half-splits per resample",
    "macro_BA_chemistry": float(chem_ba_t.mean()),
    "macro_BA_panelhalf": float(half_ba_t.mean()),
}

a2_rows = []
strata = reg["prespecified_strata"]
for j, t in enumerate(targets):
    lo, hi = [float(v) for v in np.quantile(per_target_boot[:, j], [0.05, 0.95])]
    a2_rows.append(dict(target=t,
                        mean_diff=float(diff_t[j]), ci90_lo=lo, ci90_hi=hi,
                        BA_chemistry=float(chem_ba_t[j]),
                        BA_panelhalf=float(half_ba_t[j]),
                        noninferior_delta005=bool(lo > -delta),
                        noninferior_delta010=bool(lo > -delta_s),
                        stratum=("strong" if t in strata["strong_correspondence"]
                                 else "weak" if t in strata["weak_correspondence"] else "other")))
pd.DataFrame(a2_rows).to_csv(HERE / "a2_tost_by_target.csv", index=False)
(HERE / "a2_summary.json").write_text(json.dumps(a2, indent=2), encoding="utf-8")

print("=== A1 ===")
print(json.dumps(a1_summary, indent=2))
print("=== A2 ===")
print(json.dumps(a2, indent=2))
print("\n=== A2 by stratum (delta=0.05) ===")
print(pd.DataFrame(a2_rows).groupby("stratum").noninferior_delta005.agg(["sum", "count"]))
print("\n=== strong/weak target detail ===")
print(pd.DataFrame(a2_rows).query("stratum != 'other'")[
    ["target","stratum","BA_chemistry","BA_panelhalf","mean_diff","ci90_lo","noninferior_delta005"]
].to_string(index=False))
