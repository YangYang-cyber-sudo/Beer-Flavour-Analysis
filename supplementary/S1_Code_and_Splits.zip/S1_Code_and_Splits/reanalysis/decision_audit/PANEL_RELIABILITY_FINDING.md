# Panel reliability as the hidden denominator — exploratory finding

Run 2026-11-24. **Exploratory, not preregistered.** Scripts in
`D:/tmp/ga_work_imgs/`, outputs copied here as `panel_reliability_by_attr.csv`
and `attenuation_by_attr.csv`.

## Question
After the FQP desk reject, the issue is how to keep a consequential claim
without claiming instrument replacement. This analysis tests a different
proposition: the weak chemistry–sensory correspondence may not be a failure of
chemistry, but a property of the sensory reference itself.

## Method
- Per attribute, panel split-half reliability: 60 random disjoint 8-vs-8 splits
  of the 16 assessors, Spearman correlation of the two half-panel beer means.
  Spearman–Brown to full 16-assessor reliability: r_full = 2·r_half/(1+r_half).
- ρ = Spearman correlation of the manuscript's nested-CV out-of-fold prediction
  with the continuous panel score (the reported numbers).
- Classical attenuation correction: ρ_corrected = ρ / sqrt(r_full).

## Results
- Mean panel split-half r = 0.362. Mean full-panel reliability = 0.44.
- Spearman(ρ, panel full reliability) = **0.771, P = 5.9e-11** (n=50).
  Not a pure variance artifact: partial Spearman controlling score SD = 0.642;
  controlling floor fraction = 0.728.
- By ρ quartile:

| quartile | ρ | panel reliability | floor fraction | ρ corrected |
|---|---|---|---|---|
| Q1 weakest (n=13) | 0.200 | 0.311 | 0.290 | 0.397 |
| Q2 | 0.328 | 0.444 | 0.284 | 0.508 |
| Q3 | 0.492 | 0.562 | 0.161 | 0.672 |
| Q4 strongest (n=13) | 0.670 | 0.702 | 0.067 | 0.801 |

- Named attributes: alcohol ρ 0.824 → 0.911 (reliability 0.817);
  bitterness 0.779 → 0.870 (0.802); body 0.708 → 0.888 (0.635).
  A_esters_flower 0.195 → 0.404 (reliability 0.233);
  F_esters_flower 0.179 → 0.525 (0.116); dms 0.284 → 0.413 (0.473).
- Important exception: dms has low ρ but moderate panel reliability, so the
  story is "panel reliability sets the ceiling on observable correspondence",
  NOT "every weak attribute is a panel artefact".

## Why this matters for the claim
The editor's objection presupposes the panel is a valid reference standard that
chemistry must match. These data show the reference itself has heterogeneous,
often low, reliability, and that the weak-correlation group is concentrated
where the panel's own reproducibility is lowest. This converts the conclusion
from a managerial allocation claim into a **measurement-theory claim about the
reference standard**, which is both more consequential and does not assert
replacement.

## Caveats (must be stated in any manuscript use)
- Classical attenuation assumes errors in chemistry and panel are independent
  and chemistry is error-free; both are approximations. Corrected ρ values are
  sensitivity estimates, not corrected facts.
- Split-half reliability from disjoint 8-vs-8 halves uses incomplete assessor
  coverage; 60 random splits, fixed seed 2601731.
- Exploratory; must be preregistered in the rewritten manuscript.
- Does not by itself rehabilitate "monitoring responsibilities can be
  reassigned" — it changes what the comparison is against.
