# Supplementary code, frozen validation splits and out-of-fold predictions

Companion to:

> **Above-threshold flavor compounds and trained-panel perception in commercial beer:
> panel reproducibility sets the ceiling on observable correspondence**
> *Journal of Food Science* (submitted)

This archive contains the analysis code, the frozen cross-validation splits, the
out-of-fold predictions and the derived result tables on which the findings rest.
It is provided so that every number quoted in the manuscript can be traced to a
script and to a stored output, without re-running the full model search.

---

## 1. Contents

| Directory | What it contains |
|---|---|
| `modelling/` | Nested cross-validation pipeline: data alignment, preprocessing grid, model families, selection rule, fold engine (`data.py`, `config.py`, `models.py`, `engine.py`, `__main__.py`), plus `protocol.json` (the search space as frozen before any outer-fold score was inspected) and `feature_metadata.csv` (units, transformation state and role of each of the 231 chemical columns). |
| `modelling/splits/` | **The frozen validation splits.** `definition.json` records the generating seed (2601731), the splitting unit (beer, never label), 5 outer and 3 inner folds, and the explicit flag that labels were not accessed when the splits were generated. `outer.csv` and `inner.csv` map every beer to its fold. |
| `reanalysis/` | Scripts and stored outputs behind the threshold correspondence analysis, the decomposition of prediction error, the attribution-robustness tests, the label-aggregation audit and the four-arm preprocessing comparison. Includes the out-of-fold prediction arrays (`*.npz`) and the derived label tables (`raw_panel_labels_A/B/C.csv`, `raw_panel_beer_map.csv`). |
| `support/` | Two helper modules imported by the pipeline (`audit.py`: typed table reading and numeric coercion; `tabular.py`: tabular readers). |
| `reanalysis/decision_audit/` | **Panel-reliability analysis** (Sections 2.6, 3.10, Table 9): split-half reliability, attenuation correction, independent estimator and the four prespecified falsification checks. Its own `README.md` documents reproduction; the three required input tables are shipped in `inputs/`. |

Total size ≈ 8 MB. Run logs, byte-code caches and the raw dataset are excluded.

---

## 2. Input data

The archive does **not** redistribute the measurements. Both matrices come from the
public dataset of Schreurs et al. (2024), *Nature Communications* 15:2368,
deposited at Zenodo under CC BY 4.0 (DOI 10.5281/zenodo.10653704):

- **X** – 250 beers × 231 chemical features (the `1.csv` table of the deposit)
- **Y** – 250 beers × 50 trained-panel descriptor scores (the `4.csv` table)

`modelling/data.py` aligns X and Y on `beer_id`, refuses to proceed if the beer sets
differ or if the two tables disagree on beer style, and raises an error if the shapes
are not exactly 250 × 231 and 250 × 50. No imputation or silent row dropping is
performed.

---

## 3. Correspondence with the manuscript

| Manuscript item | Where it is produced |
|---|---|
| §2.1 data assembly, 250 × 231 × 50 | `modelling/data.py` |
| §2.5 nested cross-validation, 5 outer × 3 inner folds | `modelling/engine.py`, `modelling/__main__.py` |
| §2.4 model families and preprocessing grid | `modelling/config.py`, `modelling/protocol.json` |
| §2.5 the frozen folds themselves | `modelling/splits/{definition.json, outer.csv, inner.csv}` |
| §3.1–3.2 threshold status vs. panel correspondence | `reanalysis/compound_threshold_profile.csv`, `threshold_definition_check.py`, `threshold_sensory_link.csv` |
| §3.5, §3.7 monitorability by attribute group | `reanalysis/sensory_monitorability.csv`, `monitorability_by_group.csv` |
| §3.6 decomposition of prediction error (RMSE vs. nRMSE, spread of the target) | `reanalysis/error_metrics_reanalysis.py`, `error_metrics_by_target.csv`, `error_metrics_by_group.csv`, `error_metrics_summary.json` |
| §3.5, §4.2 attribution robustness (Jaccard agreement, style permutation null) | `reanalysis/style_recheck.py`, `q2_style_recheck_summary.json`, `q2_null_baselines.csv`, `q2_full_pool_top3.csv`, `q2_within_style_top3.csv` |
| §3.8 raw panel reconstruction and the three label-aggregation alternatives | `reanalysis/raw_panel_audit.py`, `raw_panel_beer_map.csv`, `raw_panel_labels_A/B/C.csv`, `raw_panel_reconstruction_check.json` |
| Table S9 four-arm preprocessing comparison under identical frozen outer folds | `reanalysis/prep_paper_vs_routine.py`, `prep_pvr_summary.csv`, `prep_pvr_by_target.csv`, `prep_pvr_oof.npz` |
| Out-of-fold predictions (all 50 descriptors) | `reanalysis/prep_h2h_oof.npz`, `prep_h2h_addendum_oof.npz` |
| Metric equivalence between the reported and the recomputed formulations | `reanalysis/metric_equivalence_check.py`, `metric_equivalence_check.json` |
| §2.6 panel reliability, §3.10 ρ vs. reliability, Table 9 quartiles | `reanalysis/decision_audit/run_reliability_verification.py`, `PREREG_RELIABILITY.json`, `VERIFICATION_RESULT.json`, `reliability_verification_by_attr.csv`, `inputs/` |

`reanalysis/REPORT.md` and `reanalysis/prep_pvr_report.md` are the working reports
produced by `style_recheck.py` and `prep_paper_vs_routine.py`; they record, among
other things, why the style-permutation null is reported as a sensitivity check
rather than as a causal attribution.

---

## 4. Structure of the out-of-fold prediction arrays

`prep_h2h_oof.npz` and `prep_pvr_oof.npz` are NumPy archives with the keys
`y` (250 × 50, the observed panel scores), `outer` (250, the outer fold of each beer)
and `targets` (50, the descriptor names), followed by one array per prediction
source. In `prep_pvr_oof.npz` the sources are `PUBLISHED`, `W_paper`, `R_control`,
`R_fold` and `R_global`, i.e. the four preprocessing arms of Table S9 plus the
published reference. Arrays are aligned by beer index and target index, so any
metric in the manuscript can be recomputed without refitting.

---

## 5. Environment

Python 3.11 with `numpy`, `pandas`, `scipy`, `scikit-learn` (1.3+) and
`catboost` 1.2.10. The reanalysis scripts depend only on `numpy`, `pandas` and
`scipy`. A `requirements.txt` is included.

## 6. Notes on scope

- The pipeline records the search space that was frozen *before* any outer-fold
  score was seen (`protocol.json`, field `exploration_disclosure`). An earlier,
  separate seed was used to choose the candidate model families; the cohort in
  this archive is therefore not an independent external test, and is not presented
  as one.
- `reanalysis/decision_audit/run_reliability_verification.py` resolves its inputs relative to its own `inputs/` directory first, so the panel-reliability analysis can be rerun directly from this archive; the other reanalysis scripts still assume the original working layout.
- Paths inside the scripts are relative to the original working layout
  (`analysis_2026a/`, `mcprep/`). To re-run, place `modelling/` and `support/`
  on the import path or restore that layout, and point `data.load_data` at the
  directory holding `1.csv` and `4.csv`.
